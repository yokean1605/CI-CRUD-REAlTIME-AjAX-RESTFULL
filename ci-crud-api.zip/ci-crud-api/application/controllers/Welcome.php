<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
  
    public function __construct()
    {
        parent::__construct();
        $this->load->library('datatables'); 
        $this->API = base_url();
        $this->load->library('session');
        $this->load->library('curl');
        $this->load->helper('form');
        $this->load->helper('url');
    }
  

	public function index()
	{
        $this->load->view('welcome_message');
	}  
}
