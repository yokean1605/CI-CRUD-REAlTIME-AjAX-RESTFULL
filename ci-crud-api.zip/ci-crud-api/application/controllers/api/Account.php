 <?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Account extends REST_Controller {

    function __construct() { 
        parent::__construct();
        $this->load->model(array('M_users')); 
    }
   function users_post()
    {
        header('Content-Type: application/json');
        echo $this->M_users->get_lists();
    } 
   function user_post()
	{ 
		
		$data = array(
				'username' => $this->post('username'),
				'password' => $this->post('password'), 
			);  
		$this->M_users->create($data); 
		echo json_encode(array("status" => TRUE));
	}
    function user_delete($id = NULL)
    {
         if ($id) {
                 $this->M_users->get_id($id); 
        $this->M_users->delete($id);
            echo json_encode(array("status" => TRUE));
        } else {
            $this->response(array('status' => 'fail', 502));
        }   
    }
    function user_get($id = NULL)
    {
        if ($id) {
            $data = $this->M_users->get_id($id);  
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        } 
    }
    function user_put() {
        $id = $this->put('id');
        $data = array(
                    'id'       => $this->put('id'),
                    'username'          => $this->put('username'),
                    'password'    => $this->put('password'));
        
        $update = $this->M_users->update($id,$data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    } 
     
}