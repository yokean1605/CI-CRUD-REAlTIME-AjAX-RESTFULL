<?php

class M_users extends CI_Model
{

    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    //GET USERS LIST
    function get_lists()
    {
        $this->datatables->select('id,username');
        $this->datatables->from('users'); 
        return $this->datatables->generate();
    }
    // GET BY ID
    function get_id($id)
    {
        $this->db->from('users');
        $this->db->where('id',$id);
        $query = $this->db->get(); 
        return $query->row();
    }
    // CREATE USER
    function create($data)
    {
        $this->db->insert('users', $data);
        return $this->db->insert_id();
    }
    //DELETE USERS
    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('users');
    }
    //UPDATE USER
    function update($id,$data)
    {   
        $this->db->where('id', $id);
        $this->db->update('users', $data); 
    } 


}
