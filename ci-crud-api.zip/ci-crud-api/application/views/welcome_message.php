<!DOCTYPE html>
<html lang="id"> 
<head>
     <meta charset="utf-8"> 
    <title>Sidebar template</title> 
    <!-- using local links -->
    <link rel="stylesheet" href="<?php echo base_url().'_assets/';?>vendor/bootstrap/dist/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="<?php echo base_url().'_assets/';?>css/style.css"/>
<link rel="stylesheet" href="<?php echo base_url().'_assets/';?>vendor/datatables/css/dataTables.bootstrap4.css"/>
<link rel="stylesheet" href="<?php echo base_url().'_assets/';?>vendor/ionicons/css/ionicons.min.css"/>
<link rel="stylesheet" href="<?php echo base_url().'_assets/';?>vendor/datatables/css/buttons.bootstrap4.min.css"> 

    <!-- using local scripts -->
    <script src="<?php echo base_url().'_assets/';?>vendor/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url().'_assets/';?>vendor/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url().'_assets/';?>vendor/bootstrap/dist/js/bootstrap.min.js"></script> 
    <script src="<?php echo base_url().'_assets/';?>vendor/datatables/js/jquery.dataTables.js"></script>
<script src="<?php echo base_url().'_assets/';?>vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url().'_assets/';?>vendor/datatables/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url().'_assets/';?>vendor/datatables/js/buttons.bootstrap4.min.js"></script>
</head> 
<body> 
  <div class="container-fluid p-3">
  <div class="row">

  <div class="col-sm-12">
             <div class="card shadow-sm pb-2">
  <h6 class="card-header font-weight-bold text-uppercase bg-white pl-2"><i class="ion-ios-grid-view-outline pr-1"></i>ACCOUNT</h6>
  <div class="card-body p-4 p-sm-1">
 <table class="table table-bordered table-striped table-sm table-hover table-light" id="users" ></table>
  </div>   
</div>
</div>
</div>
</div>
<!-- Modal -->
<div class="modal fade" id="modal_users" role="dialog">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
                <h4 class="modal-title modal-users-title"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
     <div class="modal-body form">
                <form action="#" id="form-users" class="form-horizontal">
                    <input type="hidden" value="" name="id" id="id_user" /> 
                    <div class="form-body">
                        <div class="form-group-users form-group"> 
                            <div class="col-md-12">
                                <input name="username" id="username" placeholder="username" class="form-control" type="text"> 
                            </div>
                        </div>
                        <div class="form-group-users form-group"> 
                            <div class="col-md-12">
                                <input name="password" id="password" placeholder="password" class="form-control" type="password"> 
                            </div>
                        </div> 

                    </div>
                </form>
            </div> 
      <div class="modal-footer"> 
        <button type="button"  onclick="user_save()" class="btn btn-primary">SAVE</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
    var base_url = '<?php echo base_url();?>';
	  //CONFIG DATA 
jQuery.fn.dataTable.Api.register('processing()', function(show) {
    return this.iterator('table', function(ctx) {
        ctx.oApi._fnProcessingDisplay(ctx, show);
    });
});
$.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings) {
    return {
        "iStart": oSettings._iDisplayStart,
        "iEnd": oSettings.fnDisplayEnd(),
        "iLength": oSettings._iDisplayLength,
        "iTotal": oSettings.fnRecordsTotal(),
        "iFilteredTotal": oSettings.fnRecordsDisplay(),
        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
    };
};
//GET USERS  
setInterval(function() {
    $('#users').DataTable().ajax.reload(null, false);
    $('#users').DataTable().processing(false);
    }, 1000);

$("#users").dataTable({
    initComplete: function() {
        var api = this.api();
        $('#mytable_filter input').off('.DT').on('keyup.DT', function(e) {
            if (e.keyCode == 13) {
                api.search(this.value).draw();
            }
        });
    },
    //oLanguage: {
    //   sProcessing: "<img src='assets/img/search.gif' width='50px'>"
    //}, 
    responsive: true,
    fixedHeader: true,
    processing: true,
    searching: true,
    lengthChange: false,
    pageLength: 10,
    serverSide: true,
    deferLoading: [57, 100],
    order: [
        [1, 'desc']
    ],
    info: false,
    deferRender: true,
    dom: '<"dt-buttons"Bfli>rtp',
    ajax: {
        "url":  base_url + 'api/account/users',
        "type": "POST"
    },
    columns: [{
        "title": "<i class='ion-ios-grid-view-outline'></i>",
        "width": "5px",
        "align": "center",
        "data": "id",
        "orderable": false
    }, {
        "title": "username",
        "data": "username"
    }, {
        "title": "<i class='ion-grid'></i>",
        "data": "id"
    }],
    buttons: [{
        text: '<i class="ion-plus"></i>',
        action: function(e, dt, node, config) {
            user_create();
        },
    }, {
        text: '<i class="ion-refresh"></i>',
        action: function(e, dt, node, config) {
            var users = $('#users').DataTable()
            $('#users').DataTable().search('').draw(); 
        },
    }, {
        text: '<i class="ion-printer"></i>',
        action: function(e, dt, node, config) {
            alert('Print!');
            //this.disable(); // disable button
        },
    }, {
        text: '<i class="ion-android-download"></i>',
        action: function(e, dt, node, config) {
            alert('download!');
            //this.disable(); // disable button
        },
    }, ],
    columnDefs: [{
        targets: [2],
        type: "html",
        width: "20px",
        render: function(data, type, full) {
            return '<div class="btn-group"><a class="badge btn badge-success"href="#" onclick="user_update(' + data + ')"><i class="ion-wand "></i></a> <a class="badge btn badge-danger" href="#" onclick="user_delete(' + data + ')"><i class="ion-android-delete"></i></a></div>';
        }
    }],
    language: {
        searchPlaceholder: "Search..", 
        lengthMenu: "_MENU_", 
    }, 
    stateSave: true,
    stateLoadParams: function(settings, data) {
        return false;
    },
    bStateSave: true,
    fnStateSave: function(oSettings, oData) {
        localStorage.setItem('Users_' + window.location.pathname, JSON.stringify(oData));
    },
    fnStateLoad: function(oSettings) {
        return JSON.parse(localStorage.getItem('Users_' + window.location.pathname));
    },
    rowCallback: function(row, data, iDisplayIndex) {
        var info = this.fnPagingInfo();
        var page = info.iPage;
        var length = info.iLength;
        var index = page * length + (iDisplayIndex + 1);
        $('td:eq(0)', row).html(index);
    }
});
$('#users').DataTable().processing(true);
//INSERT USERS
function user_create()
{
    save_method = 'create_user';
    $('#form-users')[0].reset(); // reset form on modals
    $('.form-group-users').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string
    $('#modal_users').modal('show'); // show bootstrap modal
    $('.modal-users-title').text('CREATE ACCOUNT'); // Set Title to Bootstrap modal title
}
function user_save()
{  
    var url; 
    var formData = new FormData($('#form-users')[0]);
    if(save_method == 'create_user') {  
    $.ajax({
        url : base_url+"api/account/user", 
        type: "POST", 
        data: formData,
        contentType: false,
        processData: false,
        dataType: "JSON",
        success: function(data, textStatus, jqXHR) {  
                console.log('jqXHR:');
                console.log(jqXHR); 
                console.log('textStatus:');
                console.log(textStatus); 
                $('#modal_users').modal('hide'); 
            }, 
         error: function(jqXHR, textStatus, errorThrown) { 
                 console.log('jqXHR:');
                console.log(jqXHR);
                console.log('textStatus:');
                console.log(textStatus);
                console.log('errorThrown:');
                console.log(errorThrown);
                 $('#modal_users').modal('hide'); 
            }, 
    });
    } else {      
       var dataObject = { 'id': $('#id_user').val(), 'username': $('#username').val(), 'password': $('#password').val() };
         $.ajax({
        url : base_url+"api/account/user/"+$('#id_user').val(),
        type: "PUT",
        data: JSON.stringify(dataObject),
        dataType: "JSON",
         headers: {
            "Content-Type": "application/json" 
            },
         success: function(data, textStatus, jqXHR) { 
                console.log(jqXHR);
                console.log('textStatus:');
                console.log(textStatus); 
                $('#modal_users').modal('hide'); 
            }, 
             error: function(jqXHR, textStatus, errorThrown) {
                $('#modal_users').modal('hide'); 
                console.log('jqXHR:');
                console.log(jqXHR);
                console.log('textStatus:');
                console.log(textStatus);
                console.log('errorThrown:');
                console.log(errorThrown);
            },

        });
    } 
    
}
//UPDATE USERS

function user_update(id)
{
    save_method = 'update_user';
    $('#form-users')[0].reset(); // reset form on modals
    $('.form-group-users').removeClass('has-error'); // clear error class
    $('.help-block').empty(); // clear error string


    //Ajax Load data from ajax
    $.ajax({
        url : base_url+"api/account/user/"+ id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="id"]').val(data.id);
            $('[name="username"]').val(data.username);
            $('[name="password"]').val(data.password); 
            $('#modal_users').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-users-title').text('UPDATE'); // Set title to Bootstrap modal title  
        },
        error: function(jqXHR, textStatus, errorThrown) { 
                console.log('jqXHR:');
                console.log(jqXHR);
                console.log('textStatus:');
                console.log(textStatus);
                console.log('errorThrown:');
                console.log(errorThrown);
            },
    });
}

//DELETE USERS
function user_delete(id)
{
    if(confirm('Are you sure delete this data?'))
    {
        // ajax delete data to database
        $.ajax({
            url : base_url+"api/account/user/"+id, 
            type: "DELETE",
            dataType: "JSON",
            success: function(data, textStatus, jqXHR) { 
                console.log(jqXHR);
                console.log('textStatus:');
                console.log(textStatus); 
                $('#modal_users').modal('hide'); 
            }, 
             error: function(jqXHR, textStatus, errorThrown) {
                $('#modal_users').modal('hide'); 
                console.log('jqXHR:');
                console.log(jqXHR);
                console.log('textStatus:');
                console.log(textStatus);
                console.log('errorThrown:');
                console.log(errorThrown);
            },
        });

    } 
}  
</script>
</body>
</html>